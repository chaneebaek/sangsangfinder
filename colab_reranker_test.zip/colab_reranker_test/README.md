# Colab Reranker Test

Upload this whole folder to `/content/colab_reranker_test` in Google Colab, then open:

```text
reranker_stage_eval_colab.ipynb
```

Use a T4 GPU runtime. The notebook installs dependencies, asks for `PINECONE_API_KEY`, and runs:

- `BAAI/bge-reranker-v2-m3`
- `dragonkue/bge-reranker-v2-m3-ko`

Main metrics to compare:

- `NDCG@5`
- `MRR`
- `Recall@5`
- `sec/query`

The Colab script uses a rule-only feature reranker, so it does not call Gemini.
