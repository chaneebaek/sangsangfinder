"""
Colab-ready fixed-candidate reranker evaluation.

Upload the whole colab_reranker_test folder to Colab, install the dependencies,
set PINECONE_API_KEY, and run this script. It is intentionally self-contained so
it does not import the local api package or depend on a project venv.

Compares:
  - Hybrid
  - Hybrid + Feature
  - Hybrid + Cross-Encoder
  - Hybrid + Cross-Encoder + Feature
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import time
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from rank_bm25 import BM25Okapi
from sentence_transformers import CrossEncoder, SentenceTransformer


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DEFAULT_QA_PATH = DATA_DIR / "qa_test_2025.jsonl"
DEFAULT_CORPUS_PATH = DATA_DIR / "test_notices_2025.json"
DEFAULT_CHUNKS_PATH = DATA_DIR / "pinecone_chunks.json"
DEFAULT_CE_MODEL = "BAAI/bge-reranker-v2-m3"
DEFAULT_EMBED_MODEL = "jhgan/ko-sroberta-multitask"
DEFAULT_INDEX_NAME = "hansung-notices"
DEFAULT_NAMESPACE = "prod"


def load_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def tokenize_ko(text: str) -> list[str]:
    return re.findall(r"[\w가-힣]+", str(text).lower())


def parse_notice_date(value: Any) -> date | None:
    match = re.search(r"(20\d{2})\D+(\d{1,2})\D+(\d{1,2})", str(value or ""))
    if not match:
        return None
    try:
        return date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    except ValueError:
        return None


def minmax(values: list[float]) -> list[float]:
    if not values:
        return []
    lo, hi = min(values), max(values)
    if math.isclose(lo, hi):
        return [1.0 for _ in values]
    return [(value - lo) / (hi - lo) for value in values]


def rank_scores(size: int) -> list[float]:
    if size <= 1:
        return [1.0] * size
    return [1.0 - (idx / (size - 1)) for idx in range(size)]


def recall_at_k(ranked_urls: list[str], gt_url: str, k: int) -> float:
    return 1.0 if gt_url in ranked_urls[:k] else 0.0


def mrr_score(ranked_urls: list[str], gt_url: str) -> float:
    for idx, url in enumerate(ranked_urls):
        if url == gt_url:
            return 1.0 / (idx + 1)
    return 0.0


def ndcg_at_k(ranked_urls: list[str], gt_url: str, k: int) -> float:
    for idx, url in enumerate(ranked_urls[:k]):
        if url == gt_url:
            return 1.0 / math.log2(idx + 2)
    return 0.0


def compute_scores(rows: list[dict[str, Any]], k: int) -> dict[str, float | int]:
    n = len(rows)
    if not rows:
        return {f"Recall@{k}": 0.0, "MRR": 0.0, f"NDCG@{k}": 0.0, "n": 0}
    return {
        f"Recall@{k}": round(sum(recall_at_k(row["ranked_urls"], row["gt_url"], k) for row in rows) / n, 4),
        "MRR": round(sum(mrr_score(row["ranked_urls"], row["gt_url"]) for row in rows) / n, 4),
        f"NDCG@{k}": round(sum(ndcg_at_k(row["ranked_urls"], row["gt_url"], k) for row in rows) / n, 4),
        "n": n,
    }


def build_eval_examples(corpus: list[dict[str, Any]], qa_list: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    title_to_notice = {notice["title"]: notice for notice in corpus}
    examples = []
    skipped = 0
    for qa in qa_list:
        notice = None
        notice_id = qa.get("notice_id")
        if isinstance(notice_id, int) and 0 <= notice_id < len(corpus):
            candidate = corpus[notice_id]
            if candidate.get("title") == qa.get("notice_title"):
                notice = candidate
        if notice is None:
            notice = title_to_notice.get(qa.get("notice_title"))
        if notice is None or not notice.get("url"):
            skipped += 1
            continue
        examples.append(
            {
                "question": qa["question"],
                "type": qa.get("type", "unknown"),
                "notice_title": qa.get("notice_title", notice.get("title", "")),
                "gt_url": notice["url"],
                "gt_date": notice.get("date", ""),
            }
        )
    return examples, skipped


class ColabHybridSearcher:
    def __init__(
        self,
        *,
        chunks_path: Path,
        embed_model_name: str,
        pinecone_api_key: str,
        pinecone_index: str,
        pinecone_namespace: str,
    ) -> None:
        from pinecone import Pinecone

        print(f"Loading chunk cache: {chunks_path}", flush=True)
        self.cache = load_json(chunks_path)
        self.ids = []
        self.documents = []
        self.metadatas = []
        for chunk_id, row in self.cache.items():
            meta = dict(row.get("metadata") or {})
            self.ids.append(chunk_id)
            self.documents.append(row.get("document", ""))
            self.metadatas.append(meta)

        print(f"Building BM25 over {len(self.documents):,} chunks...", flush=True)
        self.bm25 = BM25Okapi([tokenize_ko(doc) for doc in self.documents])
        print(f"Loading embedder: {embed_model_name}", flush=True)
        self.embedder = SentenceTransformer(embed_model_name)
        self.pc = Pinecone(api_key=pinecone_api_key)
        self.index = self.pc.Index(pinecone_index)
        self.namespace = pinecone_namespace
        self.meta_map = dict(zip(self.ids, self.metadatas))
        self.doc_map = dict(zip(self.ids, self.documents))
        self.latest_month = self._latest_month()

    def count(self) -> int:
        try:
            stats = self.index.describe_index_stats()
            namespaces = getattr(stats, "namespaces", None) or {}
            ns_stats = namespaces.get(self.namespace)
            return int(getattr(ns_stats, "vector_count", 0) if ns_stats is not None else 0)
        except Exception:
            return len(self.ids)

    def _latest_month(self) -> int:
        values = []
        for meta in self.metadatas:
            parsed = parse_notice_date(meta.get("date"))
            if parsed:
                values.append(parsed.year * 12 + parsed.month)
        return max(values) if values else date.today().year * 12 + date.today().month

    def gt_coverage(self, gt_urls: Iterable[str]) -> tuple[int, int]:
        urls = {meta.get("url") for meta in self.metadatas if meta.get("url")}
        unique_gt = set(gt_urls)
        return len(unique_gt & urls), len(unique_gt)

    def search(self, query: str, *, candidate_k: int, alpha: float) -> list[dict[str, Any]]:
        q_emb = self.embedder.encode(query, normalize_embeddings=True).tolist()
        n_results = min(max(candidate_k * 5, 25), len(self.documents))
        response = self.index.query(
            vector=q_emb,
            top_k=n_results,
            namespace=self.namespace,
            include_metadata=True,
        )
        matches = getattr(response, "matches", None)
        if matches is None and isinstance(response, dict):
            matches = response.get("matches", [])

        raw_ids = []
        raw_sims = []
        for match in matches or []:
            match_id = getattr(match, "id", None) if not isinstance(match, dict) else match.get("id")
            score = getattr(match, "score", None) if not isinstance(match, dict) else match.get("score")
            if match_id:
                raw_ids.append(match_id)
                raw_sims.append(float(score or 0.0))

        vector_scores = {chunk_id: score for chunk_id, score in zip(raw_ids, minmax(raw_sims))}
        bm25_raw = self.bm25.get_scores(tokenize_ko(query))
        bm25_max = float(np.max(bm25_raw)) if len(bm25_raw) and np.max(bm25_raw) > 0 else 1.0
        bm25_scores = {chunk_id: float(score / bm25_max) for chunk_id, score in zip(self.ids, bm25_raw)}

        final_scores = {}
        for chunk_id in set(vector_scores) | set(bm25_scores):
            meta = self.meta_map.get(chunk_id) or {}
            posted = parse_notice_date(meta.get("date"))
            if posted:
                month_diff = max(0, self.latest_month - (posted.year * 12 + posted.month))
                recency = 1 / (1 + month_diff / 3)
            else:
                recency = 0.0
            base = alpha * vector_scores.get(chunk_id, 0.0) + (1 - alpha) * bm25_scores.get(chunk_id, 0.0)
            final_scores[chunk_id] = base * (1 + 0.15 * recency)

        seen_urls = set()
        candidates = []
        for chunk_id in sorted(final_scores, key=lambda item: final_scores[item], reverse=True):
            meta = self.meta_map.get(chunk_id) or {}
            url = meta.get("url")
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            candidates.append(
                {
                    **meta,
                    "id": chunk_id,
                    "url": url,
                    "title": meta.get("title", ""),
                    "date": meta.get("date", ""),
                    "category": meta.get("category", ""),
                    "content": self.doc_map.get(chunk_id, ""),
                    "score": round(final_scores[chunk_id], 6),
                }
            )
            if len(candidates) >= candidate_k:
                break
        return candidates


def feature_boost(notice: dict[str, Any], profile: dict[str, Any], max_date: date | None) -> float:
    text = "\n".join([notice.get("title", ""), notice.get("category", ""), notice.get("content", "")])
    boost = 0.0
    user_is_undergrad = str(profile.get("audience") or profile.get("role") or "학부생") in {"학부생", "undergraduate", ""}
    if user_is_undergrad and re.search(r"학부생|재학생|휴학생|복학생|신입생|편입생|대학생|학생", text):
        boost += 0.10
    if re.search(r"신청|지원|접수|모집|선발", text):
        boost += 0.04
    dates = []
    for match in re.finditer(r"(20\d{2})[-./년\s]+(\d{1,2})[-./월\s]+(\d{1,2})", text):
        try:
            dates.append(date(int(match.group(1)), int(match.group(2)), int(match.group(3))))
        except ValueError:
            pass
    if dates and max(dates) >= date.today():
        boost += 0.08
    posted = parse_notice_date(notice.get("date"))
    if posted and max_date:
        boost += 0.06 * math.exp(-max(0, (max_date - posted).days) / 30)
    return boost


def rerank_features(candidates: list[dict[str, Any]], profile: dict[str, Any]) -> list[dict[str, Any]]:
    max_date = max((parsed for item in candidates if (parsed := parse_notice_date(item.get("date")))), default=None)
    rows = []
    for original_rank, candidate in enumerate(candidates, start=1):
        item = dict(candidate)
        base_score = float(item.get("score") or 0.0)
        boost = feature_boost(item, profile, max_date)
        item["base_score"] = round(base_score, 6)
        item["score"] = round(base_score * (1 + boost), 6)
        item["feature_reranker"] = {"feature_boost": round(boost, 6), "original_rank": original_rank}
        rows.append(item)
    rows.sort(key=lambda item: (item.get("score", 0.0), -item["feature_reranker"]["original_rank"]), reverse=True)
    for rank, item in enumerate(rows, start=1):
        item["feature_reranker"]["rerank_rank"] = rank
    return rows


def ce_text(notice: dict[str, Any], max_chars: int) -> str:
    parts = [
        f"제목: {notice.get('title', '')}",
        f"분류: {notice.get('category', '')}",
        f"날짜: {notice.get('date', '')}",
        str(notice.get("content") or ""),
    ]
    return "\n".join(part for part in parts if part.strip())[:max_chars]


def load_ce_model(model_name: str, fp16: bool) -> CrossEncoder:
    import torch

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Loading cross-encoder: {model_name} on {device}", flush=True)
    model = CrossEncoder(model_name, max_length=512, device=device, trust_remote_code=True)
    if fp16 and device == "cuda":
        model.model.half()
    return model


def rank_with_cross_encoder(
    ce_model: CrossEncoder,
    query: str,
    candidates: list[dict[str, Any]],
    *,
    batch_size: int,
    max_chars: int,
    normalize: str,
) -> list[dict[str, Any]]:
    pairs = [(query, ce_text(candidate, max_chars)) for candidate in candidates]
    raw_scores = [float(score) for score in ce_model.predict(pairs, batch_size=batch_size, show_progress_bar=False)]
    order = sorted(range(len(candidates)), key=lambda idx: raw_scores[idx], reverse=True)
    if normalize == "rank":
        normalized_by_rank = rank_scores(len(candidates))
        norm_scores = [0.0] * len(candidates)
        for rank_idx, original_idx in enumerate(order):
            norm_scores[original_idx] = normalized_by_rank[rank_idx]
    else:
        norm_scores = minmax(raw_scores)

    rows = []
    for original_rank, (candidate, raw_score, norm_score) in enumerate(zip(candidates, raw_scores, norm_scores), start=1):
        item = dict(candidate)
        item["hybrid_score"] = candidate.get("score", 0.0)
        item["score"] = round(norm_score, 6)
        item["cross_encoder"] = {
            "model_score": round(raw_score, 6),
            "normalized_score": round(norm_score, 6),
            "original_rank": original_rank,
        }
        rows.append(item)
    rows.sort(key=lambda item: (item["score"], -item["cross_encoder"]["original_rank"]), reverse=True)
    for rank, item in enumerate(rows, start=1):
        item["cross_encoder"]["rerank_rank"] = rank
    return rows


def urls(rows: list[dict[str, Any]]) -> list[str]:
    return [row["url"] for row in rows if row.get("url")]


def evaluate(
    examples: list[dict[str, Any]],
    searcher: ColabHybridSearcher,
    *,
    candidate_k: int,
    k: int,
    alpha: float,
    profile: dict[str, Any],
    ce_model: CrossEncoder | None,
    ce_batch_size: int,
    ce_max_chars: int,
    ce_normalize: str,
) -> tuple[dict[str, list[dict[str, Any]]], dict[str, float]]:
    rows_by_system: dict[str, list[dict[str, Any]]] = defaultdict(list)
    latency: dict[str, float] = defaultdict(float)

    for idx, ex in enumerate(examples, start=1):
        query = ex["question"]
        print(f"[{idx}/{len(examples)}] {query}", flush=True)

        started = time.perf_counter()
        candidates = searcher.search(query, candidate_k=candidate_k, alpha=alpha)
        latency["Hybrid"] += time.perf_counter() - started

        started = time.perf_counter()
        feature_ranked = rerank_features(candidates, profile)
        latency["Hybrid+Feature"] += time.perf_counter() - started

        rankings = {"Hybrid": candidates, "Hybrid+Feature": feature_ranked}
        if ce_model is not None:
            started = time.perf_counter()
            ce_ranked = rank_with_cross_encoder(
                ce_model,
                query,
                candidates,
                batch_size=ce_batch_size,
                max_chars=ce_max_chars,
                normalize=ce_normalize,
            )
            latency["Hybrid+CE"] += time.perf_counter() - started

            started = time.perf_counter()
            ce_feature_ranked = rerank_features(ce_ranked, profile)
            latency["Hybrid+CE+Feature"] += time.perf_counter() - started
            rankings["Hybrid+CE"] = ce_ranked
            rankings["Hybrid+CE+Feature"] = ce_feature_ranked

        candidate_urls = urls(candidates)
        for system_name, ranked in rankings.items():
            ranked_urls = urls(ranked)
            top = ranked[0] if ranked else {}
            rows_by_system[system_name].append(
                {
                    **ex,
                    "ranked_urls": ranked_urls,
                    "top_title": top.get("title", ""),
                    "top_url": top.get("url", ""),
                    "top_date": top.get("date", ""),
                    "top_score": top.get("score"),
                    "candidate_hit": ex["gt_url"] in candidate_urls,
                    "hit": ex["gt_url"] in ranked_urls[:k],
                }
            )
    return rows_by_system, latency


def print_score_table(rows_by_system: dict[str, list[dict[str, Any]]], latency: dict[str, float], k: int) -> None:
    print("\n" + "=" * 92)
    print(f"Fixed-candidate reranker comparison (K={k})")
    print("=" * 92)
    print(f"{'system':<24} {f'Recall@{k}':>10} {'MRR':>10} {f'NDCG@{k}':>10} {'n':>6} {'sec/query':>10}")
    print("-" * 92)
    for system_name in ["Hybrid", "Hybrid+Feature", "Hybrid+CE", "Hybrid+CE+Feature"]:
        rows = rows_by_system.get(system_name)
        if not rows:
            continue
        scores = compute_scores(rows, k)
        sec_per_query = latency.get(system_name, 0.0) / max(1, len(rows))
        print(
            f"{system_name:<24} {scores[f'Recall@{k}']:>10.4f} {scores['MRR']:>10.4f} "
            f"{scores[f'NDCG@{k}']:>10.4f} {scores['n']:>6} {sec_per_query:>10.3f}"
        )


def print_type_breakdown(rows_by_system: dict[str, list[dict[str, Any]]], k: int) -> None:
    print("\n" + "=" * 92)
    print(f"Type breakdown by system (NDCG@{k})")
    print("=" * 92)
    systems = [name for name in ["Hybrid", "Hybrid+Feature", "Hybrid+CE", "Hybrid+CE+Feature"] if name in rows_by_system]
    all_types = sorted({row["type"] for rows in rows_by_system.values() for row in rows})
    print(f"{'type':<18} " + " ".join(f"{system:>18}" for system in systems))
    print("-" * 92)
    for qtype in all_types:
        cells = []
        for system in systems:
            group = [row for row in rows_by_system[system] if row["type"] == qtype]
            cells.append(f"{compute_scores(group, k)[f'NDCG@{k}']:>18.4f}")
        print(f"{qtype:<18} " + " ".join(cells))


def print_miss_samples(rows_by_system: dict[str, list[dict[str, Any]]], limit: int) -> None:
    base_rows = rows_by_system.get("Hybrid", [])
    candidate_misses = [row for row in base_rows if not row["candidate_hit"]]
    if candidate_misses:
        top_years = Counter((row.get("top_date") or "unknown")[:4] for row in candidate_misses)
        print("\n" + "=" * 92)
        print(f"Candidate-pool misses ({min(limit, len(candidate_misses))}/{len(candidate_misses)})")
        print("=" * 92)
        print("Top-1 year distribution:", dict(sorted(top_years.items())))
        for idx, row in enumerate(candidate_misses[:limit], start=1):
            print(f"{idx}. [{row['type']}] {row['question']}")
            print(f"   GT : {row['gt_date']} | {row['notice_title']}")
            print(f"   Top: {row.get('top_date', '')} | {row.get('top_title', '')}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--qa-path", type=Path, default=DEFAULT_QA_PATH)
    parser.add_argument("--corpus-path", type=Path, default=DEFAULT_CORPUS_PATH)
    parser.add_argument("--chunks-path", type=Path, default=DEFAULT_CHUNKS_PATH)
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--candidate-k", type=int, default=100)
    parser.add_argument("--alpha", type=float, default=0.5)
    parser.add_argument("--embed-model", default=os.getenv("EMBED_MODEL", DEFAULT_EMBED_MODEL))
    parser.add_argument("--ce-model", default=DEFAULT_CE_MODEL)
    parser.add_argument("--ce-batch-size", type=int, default=16)
    parser.add_argument("--ce-max-chars", type=int, default=900)
    parser.add_argument("--ce-normalize", choices=["rank", "minmax"], default="rank")
    parser.add_argument("--no-fp16", action="store_true")
    parser.add_argument("--skip-ce", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--profile-json", default="{}")
    parser.add_argument("--allow-missing-gt", action="store_true")
    parser.add_argument("--miss-limit", type=int, default=10)
    parser.add_argument("--pinecone-index", default=os.getenv("PINECONE_INDEX_NAME", DEFAULT_INDEX_NAME))
    parser.add_argument("--pinecone-namespace", default=os.getenv("PINECONE_NAMESPACE", DEFAULT_NAMESPACE))
    args = parser.parse_args()

    pinecone_api_key = os.getenv("PINECONE_API_KEY")
    if not pinecone_api_key:
        raise SystemExit("Set PINECONE_API_KEY before running.")
    if args.candidate_k < args.k:
        raise SystemExit("--candidate-k must be greater than or equal to --k")
    profile = json.loads(args.profile_json)
    if not isinstance(profile, dict):
        raise SystemExit("--profile-json must be a JSON object")

    corpus = load_json(args.corpus_path)
    qa_list = load_jsonl(args.qa_path)
    examples, skipped = build_eval_examples(corpus, qa_list)
    if args.limit is not None:
        examples = examples[: args.limit]

    print("=" * 92)
    print("Colab fixed-candidate reranker-stage evaluation")
    print("=" * 92)
    print(f"QA file        : {args.qa_path}")
    print(f"Corpus file    : {args.corpus_path}")
    print(f"Chunk cache    : {args.chunks_path}")
    print(f"QA examples    : {len(examples)} (skipped={skipped})")
    print(f"Unique GT URLs : {len(set(ex['gt_url'] for ex in examples))}")
    print(f"Hybrid alpha   : {args.alpha:.2f}")
    print(f"Candidate K    : {args.candidate_k}")
    print(f"Metric K       : {args.k}")
    print(f"CE normalize   : {args.ce_normalize}")

    searcher = ColabHybridSearcher(
        chunks_path=args.chunks_path,
        embed_model_name=args.embed_model,
        pinecone_api_key=pinecone_api_key,
        pinecone_index=args.pinecone_index,
        pinecone_namespace=args.pinecone_namespace,
    )
    print(f"Pinecone count : {searcher.count():,}")
    present, total = searcher.gt_coverage(ex["gt_url"] for ex in examples)
    print(f"GT URL coverage: {present}/{total}")
    if present < total:
        print("[WARN] Some ground-truth URLs are not present in the chunk cache; metrics will be deflated.")
        if not args.allow_missing_gt:
            print("Abort: pass --allow-missing-gt to continue.")
            return

    ce_model = None
    if not args.skip_ce:
        ce_model = load_ce_model(args.ce_model, fp16=not args.no_fp16)

    rows_by_system, latency = evaluate(
        examples,
        searcher,
        candidate_k=args.candidate_k,
        k=args.k,
        alpha=args.alpha,
        profile=profile,
        ce_model=ce_model,
        ce_batch_size=args.ce_batch_size,
        ce_max_chars=args.ce_max_chars,
        ce_normalize=args.ce_normalize,
    )
    print_score_table(rows_by_system, latency, args.k)
    print_type_breakdown(rows_by_system, args.k)
    print_miss_samples(rows_by_system, args.miss_limit)


if __name__ == "__main__":
    main()
